package com.example.mashu;

import androidx.appcompat.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import com.example.mashu.databinding.ActivityMainBinding;

public class MainActivity extends AppCompatActivity {

    static {
        System.loadLibrary("dynamicloader");
    }

    private ActivityMainBinding binding;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        binding = ActivityMainBinding.inflate(getLayoutInflater());
        setContentView(binding.getRoot());

        // Load Library Button
        Button loadLibButton = findViewById(R.id.loadLibButton);
        loadLibButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                loadLib("hello");
            }
        });

        // Unload Library Button
        Button unloadLibButton = findViewById(R.id.unloadLibButton);
        unloadLibButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                unloadLib("hello");
            }
        });
    }

    public native void loadLib(String libPath);
    public native void unloadLib(String libPath);
}