#include <jni.h>
#include <iostream>

#include <android/log.h>
extern "C" {

JNIEXPORT void JNICALL Java_com_example_mashu_MainActivity_loadLib(JNIEnv *env, jobject thiz, jstring libPath) {
    const char *path = env->GetStringUTFChars(libPath, nullptr);
    __android_log_print(ANDROID_LOG_INFO, "TRACKERS", "loadLib called with libPath: %s", path);
    env->ReleaseStringUTFChars(libPath, path);
}

JNIEXPORT void JNICALL Java_com_example_mashu_MainActivity_unloadLib(JNIEnv *env, jobject thiz, jstring libPath) {
    const char *path = env->GetStringUTFChars(libPath, nullptr);
    __android_log_print(ANDROID_LOG_INFO, "TRACKERS", "unloadLib called with libPath: %s", path);
    env->ReleaseStringUTFChars(libPath, path);
}

} // extern "C"

