#include <jni.h>
#include <android/log.h>



extern "C"
JNIEXPORT void JNICALL
        __attribute__((constructor))
Java_com_example_mashu_MainActivity_libhello_1main(JNIEnv *env, jobject thiz) {
// TODO: implement libhello_main()
__android_log_print(ANDROID_LOG_INFO, "libhello", "libhello was loaded");
}